# NHẬT DUY GUITAR — Boutique Guitar E-Commerce

Website thương mại điện tử chuyên cung cấp đàn Guitar Acoustic, Classic, phụ kiện và sách nhạc chọn lọc, thiết kế theo phong cách **Minimalist – Modern – Editorial**.

## Công nghệ sử dụng
- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS, Lucide Icons
- **Backend / Database (Giai đoạn tiếp theo)**: Supabase (PostgreSQL, Auth, Storage)

## Hướng dẫn cài đặt & chạy cục bộ
1. Clone repository về máy:
   ```bash
   git clone <repository-url>
   cd nhat-duy-guitar
   ```
2. Cài đặt thư viện:
   ```bash
   npm install
   ```
3. Tạo file môi trường:
   ```bash
   cp .env.example .env
   ```
4. Khởi chạy server phát triển:
   ```bash
   npm run dev
   ```
