import React from 'react';
import { Product } from '../../types/product';
import { ProductCard } from './ProductCard';

interface ProductGridProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  onAddToCart,
  onSelectProduct,
}) => {
  if (products.length === 0) {
    return (
      <div className="flex-1 py-24 text-center">
        <p className="font-serif text-2xl text-[#1C1C1C] mb-2">
          Chưa có sản phẩm trong danh mục này
        </p>
        <p className="text-xs text-[#85858D]">
          Vui lòng chọn danh mục khác để tiếp tục khám phá bộ sưu tập.
        </p>
      </div>
    );
  }

  return (
    <section
      aria-label="Danh sách sản phẩm"
      className="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-10 md:gap-x-8 md:gap-y-12 items-start"
    >
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          onAddToCart={onAddToCart}
          onSelectProduct={onSelectProduct}
        />
      ))}
    </section>
  );
};
