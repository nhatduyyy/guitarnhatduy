import React, { useState } from 'react';
import { Plus, Check } from 'lucide-react';
import { Product } from '../../types/product';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onSelectProduct,
}) => {
  const [justAdded, setJustAdded] = useState(false);

  const formatPrice = (amount: number) =>
    new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
    }).format(amount);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1200);
  };

  const aspectClass = product.isFeaturedTall
    ? 'aspect-[4/5]'
    : 'aspect-square';

  return (
    <article
      onClick={() => onSelectProduct(product)}
      className="group cursor-pointer flex flex-col"
    >
      <div
        className={`relative w-full ${aspectClass} bg-[#F3F4FA] rounded-xl overflow-hidden mb-3.5 transition-colors duration-300`}
      >
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105"
        />

        {(product.isNew || product.salePrice) && (
          <div className="absolute top-3.5 left-3.5 flex items-center gap-1.5">
            {product.isNew && (
              <span className="px-2 py-0.5 text-[10px] tracking-wider uppercase bg-white/85 backdrop-blur-sm text-[#1C1C1C] rounded-full">
                New
              </span>
            )}
            {product.salePrice && (
              <span className="px-2 py-0.5 text-[10px] tracking-wider uppercase bg-[#FBCFE8]/90 text-[#1C1C1C] rounded-full">
                Sale
              </span>
            )}
          </div>
        )}

        <button
          type="button"
          onClick={handleQuickAdd}
          aria-label={`Thêm nhanh ${product.name} vào giỏ hàng`}
          className={`absolute top-3.5 right-3.5 w-7 h-7 rounded-full flex items-center justify-center transition-all duration-300 ${
            justAdded
              ? 'bg-[#D8B4FE] text-[#1C1C1C] scale-105'
              : 'bg-[#1C1C1C] text-white hover:scale-110 active:scale-95'
          }`}
        >
          {justAdded ? (
            <Check className="w-3.5 h-3.5 stroke-[2.2]" />
          ) : (
            <Plus className="w-3.5 h-3.5 stroke-[2]" />
          )}
        </button>
      </div>

      <div className="flex flex-col gap-0.5 px-0.5">
        <h2 className="font-serif text-[15px] md:text-base font-medium text-[#1C1C1C] leading-snug group-hover:opacity-75 transition-opacity">
          {product.name}
        </h2>

        <div className="flex items-center gap-2 text-xs text-[#85858D]">
          {product.salePrice ? (
            <>
              <span className="text-[#1C1C1C] font-medium">
                {formatPrice(product.salePrice)}
              </span>
              <span className="line-through text-[#85858D]/70">
                {formatPrice(product.price)}
              </span>
            </>
          ) : (
            <span>{formatPrice(product.price)}</span>
          )}
        </div>
      </div>
    </article>
  );
};
