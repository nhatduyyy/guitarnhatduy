import React from 'react';
import { CategoryItem, CategorySlug } from '../../types/product';

interface ShopSidebarProps {
  categories: CategoryItem[];
  selectedCategory: CategorySlug;
  onSelectCategory: (category: CategorySlug) => void;
}

export const ShopSidebar: React.FC<ShopSidebarProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
}) => {
  return (
    <aside className="w-full lg:w-64 xl:w-72 shrink-0">
      <div className="lg:sticky lg:top-12">
        <h1 className="font-serif text-4xl md:text-5xl font-normal tracking-tight text-[#1C1C1C] mb-8 md:mb-12">
          / Shop
        </h1>

        <nav aria-label="Product Categories">
          <ul className="flex lg:flex-col gap-3 lg:gap-2.5 overflow-x-auto pb-2 lg:pb-0 no-scrollbar">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <li key={cat.id} className="shrink-0">
                  <button
                    type="button"
                    onClick={() => onSelectCategory(cat.id)}
                    className={`text-left text-xs md:text-[13px] transition-all duration-200 flex items-center gap-1.5 py-0.5 ${
                      isSelected
                        ? 'text-[#1C1C1C] font-medium translate-x-0.5'
                        : 'text-[#85858D] hover:text-[#1C1C1C]'
                    }`}
                  >
                    {isSelected && <span className="text-[#1C1C1C]">/</span>}
                    <span>{cat.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
    </aside>
  );
};
