import React from 'react';
import { X } from 'lucide-react';
import { CategoryItem, CategorySlug } from '../../types/product';

interface MobileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeNav: 'shop' | 'about' | 'contact';
  onSelectNav: (nav: 'shop' | 'about' | 'contact') => void;
  categories: CategoryItem[];
  selectedCategory: CategorySlug;
  onSelectCategory: (cat: CategorySlug) => void;
}

export const MobileDrawer: React.FC<MobileDrawerProps> = ({
  isOpen,
  onClose,
  activeNav,
  onSelectNav,
  categories,
  selectedCategory,
  onSelectCategory,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 md:hidden">
      <div
        onClick={onClose}
        className="fixed inset-0 bg-[#1C1C1C]/30 backdrop-blur-sm transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 w-72 bg-[#E5E7F5] p-6 flex flex-col justify-between shadow-xl">
        <div>
          <div className="flex items-center justify-between pb-6 border-b border-[#1C1C1C]/10">
            <span className="font-serif text-lg font-medium text-[#1C1C1C]">
              NHẬT DUY GUITAR
            </span>
            <button
              type="button"
              onClick={onClose}
              aria-label="Đóng menu"
              className="p-1.5 text-[#1C1C1C]"
            >
              <X className="w-5 h-5 stroke-[1.5]" />
            </button>
          </div>

          <div className="py-6 border-b border-[#1C1C1C]/10 flex flex-col gap-3">
            {(['shop', 'about', 'contact'] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => {
                  onSelectNav(item);
                  onClose();
                }}
                className={`text-left font-serif text-2xl ${
                  activeNav === item ? 'text-[#1C1C1C] font-medium' : 'text-[#85858D]'
                }`}
              >
                {item.charAt(0).toUpperCase() + item.slice(1)}
              </button>
            ))}
          </div>

          <div className="py-6">
            <p className="text-[11px] uppercase tracking-widest text-[#85858D] mb-4">
              Danh mục sản phẩm
            </p>
            <ul className="flex flex-col gap-2.5">
              {categories.map((cat) => {
                const isSelected = selectedCategory === cat.id;
                return (
                  <li key={cat.id}>
                    <button
                      type="button"
                      onClick={() => {
                        onSelectCategory(cat.id);
                        onClose();
                      }}
                      className={`text-sm flex items-center gap-1.5 ${
                        isSelected
                          ? 'text-[#1C1C1C] font-medium'
                          : 'text-[#85858D]'
                      }`}
                    >
                      {isSelected && <span>/</span>}
                      <span>{cat.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        <div className="pt-4 border-t border-[#1C1C1C]/10">
          <button
            type="button"
            className="w-full py-2.5 rounded-full bg-[#1C1C1C] text-[#F3F4FA] text-xs font-medium"
          >
            Account
          </button>
        </div>
      </div>
    </div>
  );
};
