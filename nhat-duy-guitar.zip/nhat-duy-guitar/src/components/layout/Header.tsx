import React from 'react';
import { Menu } from 'lucide-react';

interface HeaderProps {
  activeNav: 'shop' | 'about' | 'contact';
  onSelectNav: (nav: 'shop' | 'about' | 'contact') => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenMobileMenu: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeNav,
  onSelectNav,
  cartCount,
  onOpenCart,
  onOpenMobileMenu,
}) => {
  return (
    <header className="w-full px-6 md:px-12 lg:px-16 pt-7 pb-6 flex items-center justify-between">
      {/* Left: Brand Logo */}
      <a
        href="#shop"
        onClick={(e) => {
          e.preventDefault();
          onSelectNav('shop');
        }}
        className="font-serif text-xl md:text-2xl font-medium tracking-tight text-[#1C1C1C] select-none"
      >
        NHẬT DUY GUITAR
      </a>

      {/* Center: Minimalist Pill Navigation (Desktop & Tablet) */}
      <nav aria-label="Main Navigation" className="hidden md:flex items-center gap-2">
        {(['shop', 'about', 'contact'] as const).map((item) => {
          const isActive = activeNav === item;
          const label = item.charAt(0).toUpperCase() + item.slice(1);
          return (
            <button
              key={item}
              onClick={() => onSelectNav(item)}
              className={`px-4 py-1.5 rounded-full text-xs tracking-wide transition-all duration-200 ${
                isActive
                  ? 'bg-[#1C1C1C] text-[#F3F4FA] font-medium'
                  : 'text-[#1C1C1C]/80 hover:text-[#1C1C1C] hover:bg-white/40'
              }`}
            >
              {label}
            </button>
          );
        })}
      </nav>

      {/* Right: Account & Cart */}
      <div className="hidden md:flex items-center gap-6 text-xs text-[#1C1C1C]">
        <button
          type="button"
          className="hover:opacity-65 transition-opacity"
        >
          Account
        </button>
        <button
          type="button"
          onClick={onOpenCart}
          className="hover:opacity-65 transition-opacity font-medium"
        >
          Cart ({cartCount})
        </button>
      </div>

      {/* Mobile Controls */}
      <div className="flex md:hidden items-center gap-4">
        <button
          type="button"
          onClick={onOpenCart}
          className="text-xs font-medium text-[#1C1C1C]"
        >
          Cart ({cartCount})
        </button>
        <button
          type="button"
          onClick={onOpenMobileMenu}
          aria-label="Mở menu"
          className="p-1.5 text-[#1C1C1C] hover:bg-white/40 rounded-lg"
        >
          <Menu className="w-5 h-5 stroke-[1.5]" />
        </button>
      </div>
    </header>
  );
};
