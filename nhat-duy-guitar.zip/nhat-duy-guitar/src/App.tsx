import { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { MobileDrawer } from './components/layout/MobileDrawer';
import { ShopPage } from './pages/ShopPage';
import { SHOP_CATEGORIES } from './data/mockProducts';
import { CartItem, CategorySlug, Product } from './types/product';

export function App() {
  const [activeNav, setActiveNav] = useState<'shop' | 'about' | 'contact'>('shop');
  const [selectedCategory, setSelectedCategory] = useState<CategorySlug>('all');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('ndg_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('ndg_cart', JSON.stringify(cart));
  }, [cart]);

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });

    setToastMessage(`Đã thêm "${product.name}" vào giỏ hàng`);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  const handleSelectProduct = (product: Product) => {
    setToastMessage(`Đang mở chi tiết: ${product.name}`);
    setTimeout(() => setToastMessage(null), 2000);
  };

  return (
    <div className="min-h-screen editorial-ambient-bg flex flex-col">
      <Header
        activeNav={activeNav}
        onSelectNav={setActiveNav}
        cartCount={totalCartItems}
        onOpenCart={() => setToastMessage(`Giỏ hàng hiện có ${totalCartItems} sản phẩm`)}
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
      />

      <MobileDrawer
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        activeNav={activeNav}
        onSelectNav={setActiveNav}
        categories={SHOP_CATEGORIES}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />

      <ShopPage
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        onAddToCart={handleAddToCart}
        onSelectProduct={handleSelectProduct}
      />

      {toastMessage && (
        <div
          role="status"
          className="fixed bottom-6 right-6 z-50 bg-[#1C1C1C] text-[#F3F4FA] text-xs px-4 py-3 rounded-full shadow-lg transition-all duration-300"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}

export default App;
