export type CategorySlug =
  | 'all'
  | 'acoustic-guitar'
  | 'classic-guitar'
  | 'guitar-accessories'
  | 'guitar-books';

export interface CategoryItem {
  id: CategorySlug;
  label: string;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  slug: string;
  category: Exclude<CategorySlug, 'all'>;
  brand: string;
  price: number;
  salePrice?: number;
  image: string;
  description: string;
  specs: Record<string, string>;
  stock: number;
  isNew?: boolean;
  isFeaturedTall?: boolean;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
