import { CategoryItem, Product } from '../types/product';

export const SHOP_CATEGORIES: CategoryItem[] = [
  { id: 'all', label: 'All Products' },
  { id: 'acoustic-guitar', label: 'Acoustic Guitar' },
  { id: 'classic-guitar', label: 'Classic Guitar' },
  { id: 'guitar-accessories', label: 'Guitar Accessories' },
  { id: 'guitar-books', label: 'Guitar Books' },
];

export const MOCK_PRODUCTS: Product[] = [
  {
    id: 'prod-01',
    sku: 'NDG-AC-001',
    name: 'Thuận Guitar AT07NC Custom',
    slug: 'thuan-guitar-at07nc-custom',
    category: 'acoustic-guitar',
    brand: 'Thuận Guitar',
    price: 14500000,
    image:
      'https://images.unsplash.com/photo-1550985616-10810253b84d?auto=format&fit=crop&w=900&q=85',
    description:
      'Dáng Auditorium khuyết tinh tế, mặt top Sitka Spruce nguyên tấm kết hợp lưng hông Indian Rosewood cho dải âm trầm ấm và độ ngân sâu.',
    specs: {
      'Mặt Top': 'Solid Sitka Spruce',
      'Lưng & Hông': 'Indian Rosewood',
      'Dáng đàn': 'Auditorium Cutaway',
      'Dây đàn': 'Elixir Nanoweb Phosphor Bronze',
    },
    stock: 4,
    isNew: true,
    isFeaturedTall: false,
    createdAt: '2026-10-01',
  },
  {
    id: 'prod-02',
    sku: 'NDG-AC-002',
    name: 'Taylor GS Mini-e Koa Plus',
    slug: 'taylor-gs-mini-e-koa-plus',
    category: 'acoustic-guitar',
    brand: 'Taylor',
    price: 26800000,
    salePrice: 24900000,
    image:
      'https://images.unsplash.com/photo-1525201548942-d8732f6617a0?auto=format&fit=crop&w=900&q=85',
    description:
      'Thiết kế nhỏ gọn giàu cảm hứng với gỗ Hawaiian Koa vân đẹp mắt, tích hợp hệ thống khuếch đại ES2 trung thực.',
    specs: {
      'Mặt Top': 'Solid Hawaiian Koa',
      'Lưng & Hông': 'Layered Koa',
      'Pickup': 'Expression System 2',
      'Bao đàn': 'Aerocase đi kèm',
    },
    stock: 3,
    isFeaturedTall: true,
    createdAt: '2026-09-20',
  },
  {
    id: 'prod-03',
    sku: 'NDG-ACC-001',
    name: 'G7th Performance 3 ART Capo',
    slug: 'g7th-performance-3-art-capo',
    category: 'guitar-accessories',
    brand: 'G7th',
    price: 1250000,
    image:
      'https://images.unsplash.com/photo-1516924962500-2b4b3b99ea02?auto=format&fit=crop&w=900&q=85',
    description:
      'Công nghệ phân bổ lực ép thích ứng ART giúp giữ chuẩn cao độ từng dây đàn mà không gây phô tiếng.',
    specs: {
      'Chất liệu': 'Thép không gỉ Satin Black',
      'Cơ chế': 'Unique Tension Control',
      'Tương thích': 'Acoustic & Electric 6 dây',
    },
    stock: 15,
    isFeaturedTall: false,
    createdAt: '2026-09-15',
  },
  {
    id: 'prod-04',
    sku: 'NDG-CL-001',
    name: 'Cordoba C7 CD Classical',
    slug: 'cordoba-c7-cd-classical',
    category: 'classic-guitar',
    brand: 'Cordoba',
    price: 11200000,
    image:
      'https://images.unsplash.com/photo-1564186763535-ebb21ef5277f?auto=format&fit=crop&w=900&q=85',
    description:
      'Chế tác thủ công theo truyền thống Tây Ban Nha với mặt gỗ Western Red Cedar nguyên tấm mang lại âm sắc mộc mạc, truyền cảm.',
    specs: {
      'Mặt Top': 'Solid Canadian Cedar',
      'Lưng & Hông': 'Rosewood',
      'Độ rộng lược đàn': '52mm',
      'Ty chỉnh cần': 'Dual Action Truss Rod',
    },
    stock: 6,
    isFeaturedTall: false,
    createdAt: '2026-09-10',
  },
  {
    id: 'prod-05',
    sku: 'NDG-BK-001',
    name: 'Modern Fingerstyle & Percussive Arrangement',
    slug: 'modern-fingerstyle-percussive-arrangement',
    category: 'guitar-books',
    brand: 'Nhật Duy Editions',
    price: 380000,
    image:
      'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=900&q=85',
    description:
      'Tuyển tập kỹ thuật chuyển soạn Fingerstyle hiện đại, Open Tuning và kỹ thuật gõ thùng (Body Percussion) từ cơ bản đến nâng cao.',
    specs: {
      'Số trang': '168 trang in giấy mỹ thuật',
      'Định dạng': 'Bản nhạc chuẩn + TAB chi tiết',
      'Kèm theo': 'Audio & Video hướng dẫn trực tuyến',
    },
    stock: 25,
    isNew: true,
    isFeaturedTall: false,
    createdAt: '2026-10-05',
  },
  {
    id: 'prod-06',
    sku: 'NDG-CL-002',
    name: 'Alhambra 5P Conservatory',
    slug: 'alhambra-5p-conservatory',
    category: 'classic-guitar',
    brand: 'Alhambra',
    price: 23500000,
    image:
      'https://images.unsplash.com/photo-1510915361894-db8b60106cb1?auto=format&fit=crop&w=900&q=85',
    description:
      'Dòng đàn bán chuyên dành cho sinh viên nhạc viện và nghệ sĩ biểu diễn, hoàn thiện thủ công tại Tây Ban Nha.',
    specs: {
      'Mặt Top': 'Solid Red Cedar',
      'Lưng & Hông': 'Indian Rosewood',
      'Cần đàn': 'Cedar gia cố Ebony',
      'Xuất xứ': 'Tây Ban Nha',
    },
    stock: 2,
    isFeaturedTall: true,
    createdAt: '2026-08-28',
  },
];
