import React, { useMemo, useState } from 'react';
import { MOCK_PRODUCTS, SHOP_CATEGORIES } from '../data/mockProducts';
import { CategorySlug, Product } from '../types/product';
import { ShopSidebar } from '../components/shop/ShopSidebar';
import { ProductGrid } from '../components/shop/ProductGrid';

interface ShopPageProps {
  selectedCategory: CategorySlug;
  onSelectCategory: (category: CategorySlug) => void;
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export const ShopPage: React.FC<ShopPageProps> = ({
  selectedCategory,
  onSelectCategory,
  onAddToCart,
  onSelectProduct,
}) => {
  const [isTransitioning, setIsTransitioning] = useState(false);

  const handleCategoryChange = (category: CategorySlug) => {
    if (category === selectedCategory) return;
    setIsTransitioning(true);
    setTimeout(() => {
      onSelectCategory(category);
      setIsTransitioning(false);
    }, 140);
  };

  const filteredProducts = useMemo(() => {
    if (selectedCategory === 'all') return MOCK_PRODUCTS;
    return MOCK_PRODUCTS.filter((p) => p.category === selectedCategory);
  }, [selectedCategory]);

  return (
    <main className="w-full px-6 md:px-12 lg:px-16 pt-6 md:pt-10 pb-24">
      <div className="flex flex-col lg:flex-row gap-10 lg:gap-12 items-start">
        <ShopSidebar
          categories={SHOP_CATEGORIES}
          selectedCategory={selectedCategory}
          onSelectCategory={handleCategoryChange}
        />

        <div
          className={`flex-1 w-full transition-opacity duration-200 ${
            isTransitioning ? 'opacity-30' : 'opacity-100'
          }`}
        >
          <ProductGrid
            products={filteredProducts}
            onAddToCart={onAddToCart}
            onSelectProduct={onSelectProduct}
          />
        </div>
      </div>
    </main>
  );
};
